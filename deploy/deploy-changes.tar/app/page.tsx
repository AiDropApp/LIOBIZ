﻿import Hero from "@/components/hero/Hero";
import AboutLiobiz from "@/components/AboutLiobiz";
import Services from "@/components/Services";
import Portfolio from "@/components/Portfolio";
import Process from "@/components/Process";
import Backstage from "@/components/Backstage";
import Plans from "@/components/Plans";
import CreativePartners from "@/components/CreativePartners";
import FAQ from "@/components/FAQ";
import BlogSection from "@/components/BlogSection";
import Testimonials from "@/components/Testimonials";
import Partners from "@/components/Partners";
import LoadingScreen from "@/components/LoadingScreen";
import SmoothScroll from "@/components/SmoothScroll";
import SiteShell from "@/components/SiteShell";
import { defaultLanding } from "@/lib/cms-defaults";
import type { BlogPost } from "@/lib/blog-defaults";
import { readPublicSiteContent } from "@/lib/content-store";
import { normalizePortfolioCategories } from "@/lib/portfolio";
import { isBlogPublished } from "@/lib/validation";

function pickHomeBlogPosts(posts: BlogPost[]) {
  return posts
    .filter(isBlogPublished)
    .sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime())
    .slice(0, 3);
}

export default async function HomePage() {
  const content = await readPublicSiteContent();
  const landing = { ...defaultLanding, ...content.landing };

  return (
    <SiteShell mainClassName="">
      <SmoothScroll>
        <LoadingScreen />
        <Hero initialLanding={landing} />
        <AboutLiobiz initialLanding={landing} />
        <Services initialLanding={landing} />
        <Portfolio
          initialLanding={landing}
          initialItems={content.portfolio}
          initialCategories={normalizePortfolioCategories(content.portfolioCategories)}
        />
        <Process initialLanding={landing} initialSteps={content.pages.processSteps} />
        <Backstage
          initialLanding={landing}
          initialGallery={content.backstage}
          initialTeamStats={content.teamStats}
        />
        <Plans initialLanding={landing} initialPlans={content.plans} />
        <CreativePartners initialLanding={landing} initialPartners={content.creativePartners} />
        <FAQ initialLanding={landing} initialFaq={content.faq} />
        <BlogSection initialLanding={landing} initialPosts={pickHomeBlogPosts(content.blogPosts)} />
        <Testimonials initialLanding={landing} initialTestimonials={content.testimonials} />
        <Partners initialLanding={landing} initialPartners={content.partners} />
      </SmoothScroll>
    </SiteShell>
  );
}
