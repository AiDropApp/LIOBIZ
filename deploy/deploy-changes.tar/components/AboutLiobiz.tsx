"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import EditableText from "@/components/cms-edit/EditableText";
import EditableCta from "@/components/cms-edit/EditableCta";
import EditableRichText from "@/components/cms-edit/EditableRichText";
import EditableImage from "@/components/cms-edit/EditableImage";
import { useCmsEdit } from "@/components/cms-edit/CmsEditProvider";
import { defaultLanding, type LandingContent } from "@/lib/cms-defaults";

export default function AboutLiobiz({ initialLanding }: { initialLanding?: LandingContent }) {
  const cms = useCmsEdit();
  const [landing, setLanding] = useState<LandingContent>(initialLanding ?? defaultLanding);

  useEffect(() => {
    if (initialLanding || cms?.landing) return;
    fetch("/api/content", { cache: "no-store" })
      .then((r) => r.json())
      .then((data) => {
        if (data?.landing) setLanding({ ...defaultLanding, ...data.landing });
      })
      .catch(() => undefined);
  }, [cms?.landing, initialLanding]);

  const active = cms?.landing ?? landing;

  return (
    <section id="about-liobiz" className="about-liobiz section-block">
      <div className="container mx-auto">
        <div className="grid items-center gap-12 lg:grid-cols-[1fr_1.05fr] lg:gap-16">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="order-2 text-center lg:order-1 lg:text-right"
          >
            <EditableText path="landing.aboutLabel" className="section-label">
              {active.aboutLabel}
            </EditableText>
            <EditableText path="landing.aboutTitle" as="h2" className="section-title mt-2 text-[1.75rem] md:text-3xl lg:text-[2.35rem]">
              {active.aboutTitle}
            </EditableText>
            <EditableRichText
              path="landing.aboutText1"
              fallback={active.aboutText1}
              className="mx-auto mt-5 max-w-xl lg:mx-0"
              paragraphClassName="text-muted leading-8"
            />
            <EditableRichText
              path="landing.aboutText2"
              fallback={active.aboutText2}
              className="mx-auto mt-4 max-w-xl lg:mx-0"
              paragraphClassName="text-muted leading-8"
            />
            <EditableCta
              labelPath="landing.aboutLinkCta"
              hrefPath="landing.aboutLinkHref"
              label={active.aboutLinkCta}
              href={active.aboutLinkHref}
              className="btn-accent btn-accent--black mt-8"
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.08 }}
            className="about-liobiz-visual order-1 lg:order-2"
          >
            <div className="about-liobiz-main">
              <EditableImage
                path="landing.aboutImage1"
                src={active.aboutImage1}
                alt="فضای کار لیوبیز"
                fill
                className="object-cover"
                sizes="(max-width: 1024px) 100vw, 48vw"
                uploadKind="about"
              />
            </div>
            <div className="about-liobiz-float">
              <EditableImage
                path="landing.aboutImage2"
                src={active.aboutImage2}
                alt="جلسه تیم لیوبیز"
                fill
                className="object-cover"
                sizes="280px"
                uploadKind="about"
              />
            </div>
            <EditableText path="landing.aboutBadge" className="about-liobiz-badge">
              {active.aboutBadge}
            </EditableText>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
