"use client";

import { useEffect, useState } from "react";
import { Instagram, Linkedin, Send, Phone, Mail, MapPin } from "lucide-react";
import Link from "next/link";
import { SITE, SOCIAL_LINKS } from "@/lib/constants";
import { defaultLanding, type LandingContent } from "@/lib/cms-defaults";
import EditableText from "@/components/cms-edit/EditableText";
import EditableRichText from "@/components/cms-edit/EditableRichText";
import EditableCta from "@/components/cms-edit/EditableCta";
import CmsEditPopover from "@/components/cms-edit/CmsEditPopover";
import { useCmsEdit } from "@/components/cms-edit/CmsEditProvider";
import {
  defaultFooterQuickLinks,
  defaultFooterServiceLinks,
  type LinkItem,
} from "@/lib/landing-defaults";
import SocialShare from "@/components/SocialShare";

function SocialIcon({ name }: { name: string }) {
  if (name === "Instagram") return <Instagram size={18} />;
  if (name === "LinkedIn") return <Linkedin size={18} />;
  if (name === "Telegram") return <Send size={18} />;
  return <span className="text-xs font-bold">Be</span>;
}

type SiteInfo = {
  description?: string;
  phone?: string;
  email?: string;
  address?: string;
  footerText?: string;
  brandDisplayName?: string;
  socials?: Array<{ name: string; href: string }>;
};

export default function Footer() {
  const cms = useCmsEdit();
  const [landing, setLanding] = useState<LandingContent>(defaultLanding);
  const [quickLinks, setQuickLinks] = useState<LinkItem[]>(defaultFooterQuickLinks);
  const [serviceLinks, setServiceLinks] = useState<LinkItem[]>(defaultFooterServiceLinks);
  const [site, setSite] = useState<SiteInfo>({
    description: SITE.description,
    phone: SITE.phone,
    email: SITE.email,
    address: SITE.address,
    footerText: SITE.description,
    brandDisplayName: "LIOBIZ",
    socials: SOCIAL_LINKS,
  });

  useEffect(() => {
    fetch("/api/content", { cache: "no-store" })
      .then((r) => r.json())
      .then((data) => {
        if (data?.landing) setLanding({ ...defaultLanding, ...data.landing });
        if (Array.isArray(data?.footerQuickLinks)) setQuickLinks(data.footerQuickLinks);
        if (Array.isArray(data?.footerServiceLinks)) setServiceLinks(data.footerServiceLinks);
        if (data?.site) {
          setSite({
            description: data.site.description || SITE.description,
            phone: data.site.phone || SITE.phone,
            email: data.site.email || SITE.email,
            address: data.site.address || SITE.address,
            footerText: data.site.footerText || data.site.description || SITE.description,
            brandDisplayName: data.site.brandDisplayName || "LIOBIZ",
            socials:
              Array.isArray(data.site.socials) && data.site.socials.length > 0
                ? data.site.socials
                : SOCIAL_LINKS,
          });
        }
      })
      .catch(() => undefined);
  }, []);

  const phone = site.phone || SITE.phone;
  const email = site.email || SITE.email;
  const socials = site.socials || SOCIAL_LINKS;

  return (
    <footer id="contact" className="site-footer">
      <div className="footer-panel">
        <div className="footer-panel-inner">
          <div className="footer-cta mb-14 flex flex-col items-center gap-5 rounded-[var(--radius-card)] border border-white/10 bg-white/[0.03] px-6 py-8 text-center md:flex-row md:justify-between md:px-8 md:text-right">
            <div>
              <EditableText path="landing.footerCtaTitle" as="p" className="footer-cta-title text-2xl font-bold md:text-3xl">
                {landing.footerCtaTitle}
              </EditableText>
              <EditableRichText path="landing.footerCtaText" fallback={landing.footerCtaText} className="mt-2" />
            </div>
            {cms?.isAdmin && cms.editMode ? (
              <div className="flex flex-col items-center gap-2">
                <EditableText path="landing.footerCtaButton" className="btn-accent px-8">
                  {landing.footerCtaButton}
                </EditableText>
                <EditableText path="landing.footerCtaHref" dir="ltr" className="cms-cta-href">
                  {landing.footerCtaHref}
                </EditableText>
              </div>
            ) : (
              <Link href={landing.footerCtaHref} className="btn-accent px-8">
                {landing.footerCtaButton}
              </Link>
            )}
          </div>

          <div className="grid gap-10 md:grid-cols-2 xl:grid-cols-4">
            <div>
              <EditableText path="site.brandDisplayName" as="p" className="mb-2 text-xl font-extrabold tracking-wide text-white">
                {site.brandDisplayName || "LIOBIZ"}
              </EditableText>
              <p className="mb-6 max-w-sm leading-relaxed text-muted">
                <EditableText path="site.footerText" multiline>
                  {site.footerText || site.description || SITE.description}
                </EditableText>
              </p>
              <div className="footer-socials">
                {socials.map((link, index) =>
                  cms?.isAdmin && cms.editMode ? (
                    <div key={link.name} className="footer-social cms-editable-card relative">
                      <SocialIcon name={link.name} />
                      <CmsEditPopover
                        className="cms-edit-popover-wrap--social"
                        buttonLabel="✏️"
                        fields={[
                          { path: `site.socials.${index}.name`, label: "نام" },
                          { path: `site.socials.${index}.href`, label: "لینk", dir: "ltr" },
                        ]}
                      />
                    </div>
                  ) : (
                    <a
                      key={link.name}
                      href={link.href}
                      target="_blank"
                      rel="nofollow noopener noreferrer"
                      className="footer-social"
                    >
                      <SocialIcon name={link.name} />
                      <span className="footer-social-name">{link.name}</span>
                    </a>
                  ),
                )}
              </div>
            </div>

            <div>
              <EditableText path="landing.footerQuickLinksTitle" as="p" className="footer-col-title mb-4 text-lg font-bold">
                {landing.footerQuickLinksTitle}
              </EditableText>
              <ul className="space-y-3">
                {quickLinks.map((link, index) => (
                  <li key={`${link.href}-${index}`} className="cms-editable-card">
                    {cms?.isAdmin && cms.editMode ? (
                      <div className="space-y-1">
                        <EditableText path={`footerQuickLinks.${index}.label`}>{link.label}</EditableText>
                        <CmsEditPopover
                          buttonLabel="🔗"
                          fields={[{ path: `footerQuickLinks.${index}.href`, label: "لینk", dir: "ltr" }]}
                        />
                      </div>
                    ) : (
                      <Link href={link.href} className="text-muted transition-colors hover:text-white">
                        {link.label}
                      </Link>
                    )}
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <EditableText path="landing.footerServicesTitle" as="p" className="footer-col-title mb-4 text-lg font-bold">
                {landing.footerServicesTitle}
              </EditableText>
              <ul className="space-y-3">
                {serviceLinks.map((link, index) => (
                  <li key={`${link.label}-${index}`} className="cms-editable-card">
                    {cms?.isAdmin && cms.editMode ? (
                      <div className="space-y-1">
                        <EditableText path={`footerServiceLinks.${index}.label`}>{link.label}</EditableText>
                        <CmsEditPopover
                          buttonLabel="🔗"
                          fields={[{ path: `footerServiceLinks.${index}.href`, label: "لینk", dir: "ltr" }]}
                        />
                      </div>
                    ) : (
                      <Link href={link.href} className="text-muted transition-colors hover:text-white">
                        {link.label}
                      </Link>
                    )}
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <EditableText path="landing.footerContactTitle" as="p" className="footer-col-title mb-4 text-lg font-bold">
                {landing.footerContactTitle}
              </EditableText>
              <ul className="space-y-3.5 text-muted">
                <li className="flex items-start gap-2.5">
                  <Phone size={16} className="mt-1 shrink-0 text-primary" aria-hidden="true" />
                  <a
                    href={`tel:${phone.replace(/\s/g, "")}`}
                    className="transition-colors hover:text-white"
                    dir="ltr"
                  >
                    <EditableText path="site.phone" dir="ltr">
                      {phone}
                    </EditableText>
                  </a>
                </li>
                <li className="flex items-start gap-2.5">
                  <Mail size={16} className="mt-1 shrink-0 text-primary" aria-hidden="true" />
                  <a href={`mailto:${email}`} className="transition-colors hover:text-white" dir="ltr">
                    <EditableText path="site.email" dir="ltr">
                      {email}
                    </EditableText>
                  </a>
                </li>
                <li className="flex items-start gap-2.5">
                  <MapPin size={16} className="mt-1 shrink-0 text-primary" aria-hidden="true" />
                  <EditableText path="site.address" as="span" multiline>
                    {site.address || SITE.address}
                  </EditableText>
                </li>
                <li>
                  <EditableCta
                    labelPath="landing.footerContactPageLink"
                    hrefPath="landing.footerContactPageHref"
                    label={landing.footerContactPageLink}
                    href={landing.footerContactPageHref}
                    className="text-primary-soft transition-colors hover:text-white"
                  />
                </li>
              </ul>
            </div>
          </div>

          <SocialShare />

          <div className="mt-12 border-t border-white/5 pt-6 text-center text-sm text-white/40">
            © {new Date().getFullYear()}{" "}
            <EditableText path="landing.footerCopyright" as="span">
              {landing.footerCopyright}
            </EditableText>
          </div>
        </div>
      </div>
    </footer>
  );
}
