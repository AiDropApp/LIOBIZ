exports.id=9955,exports.ids=[9955],exports.modules={37966:(a,b,c)=>{"use strict";c.d(b,{G8:()=>i,Xn:()=>h,m5:()=>e});var d=c(55511);let e="liobiz_auth";function f(){return process.env.AUTH_SECRET?.trim()||null}function g(a){return a&&"object"==typeof a&&a.userId&&a.email&&a.role&&("admin"===a.role||"client"===a.role)?{userId:Number(a.userId),email:String(a.email),name:String(a.name||""),role:a.role}:null}function h(a){let b=JSON.stringify(a),c=f();if(!c)return b;let e=(0,d.createHmac)("sha256",c).update(b).digest("base64url"),g=Buffer.from(b,"utf8").toString("base64url");return`${g}.${e}`}function i(a){if(!a)return null;try{let b=a;if(a.includes(`${e}=`)||a.includes(";")){let c=a.match(RegExp(`(?:^|;\\s*)${e}=([^;]*)`));b=c?.[1]?c[1]:""}if(!b)return null;let c=function(a){let b,c=f();if(!c)return null;let e=a.lastIndexOf(".");if(e<=0)return null;let h=a.slice(0,e),i=a.slice(e+1);try{b=Buffer.from(h,"base64url").toString("utf8")}catch{return null}let j=(0,d.createHmac)("sha256",c).update(b).digest("base64url");try{let a=Buffer.from(i),b=Buffer.from(j);if(a.length!==b.length||!(0,d.timingSafeEqual)(a,b))return null}catch{return null}return g(JSON.parse(b))}(b);if(c)return c;return f(),null}catch{return null}}},55535:(a,b,c)=>{"use strict";c.d(b,{Av:()=>m,GC:()=>j,XD:()=>n,bV:()=>l,uj:()=>o});var d=c(86802),e=c(10641),f=c(66147),g=c(82082),h=c(79418);function i(a){if(a?.role!=="admin")return null;let b=(0,f.lC)(a.userId);return!b||b.blocked||"admin"!==b.role?null:b}function j(a){return i((0,f.G8)(a.headers.get("cookie")))}async function k(){let a=await (0,d.UL)();return i((0,f.G8)(a.get(f.m5)?.value))}async function l(){let a=await k();return a||e.NextResponse.json({message:"دسترسی غیرمجاز"},{status:401})}function m(){return(0,h.dP)()?null:e.NextResponse.json({message:"Files.ir پیکربندی نشده. FILESIR_ACCESS_TOKEN یا FILESIR_EMAIL/PASSWORD را در .env.local تنظیم کنید.",configured:!1},{status:503})}function n(a){if(a instanceof g.ns)return e.NextResponse.json({message:a.message,details:a.body},{status:a.status});let b=a instanceof Error?a.message:"خطای ناشناخته";return e.NextResponse.json({message:b},{status:500})}function o(a){return a.startsWith("image/")||a.startsWith("video/")}},66147:(a,b,c)=>{"use strict";c.d(b,{BE:()=>l,Er:()=>k,G8:()=>g.G8,Gs:()=>m,M$:()=>h,OB:()=>j,VX:()=>i,k3:()=>o,lC:()=>n,m5:()=>g.m5});var d=c(7028),e=c(48689),f=c(84862),g=c(37966);function h(a){return{userId:a.id,email:a.email,name:a.name,role:a.role}}function i(a,b){a.cookies.set(g.m5,(0,g.Xn)(b),{httpOnly:!0,sameSite:"lax",path:"/",maxAge:604800,secure:!0})}function j(a){a.cookies.set(g.m5,"",{httpOnly:!0,sameSite:"lax",path:"/",maxAge:0})}async function k(a){return d.Ay.hash(a,10)}async function l(a,b){return d.Ay.compare(a,b)}function m(a){return(0,f.Lf)().select().from(f.VV).where((0,e.eq)(f.VV.email,a.toLowerCase())).get()}function n(a){return(0,f.Lf)().select().from(f.VV).where((0,e.eq)(f.VV.id,a)).get()}function o(a){return"admin"===a?"/admin":"/dashboard"}},78335:()=>{},79418:(a,b,c)=>{"use strict";c.d(b,{If:()=>g,dP:()=>f,eW:()=>d});let d=process.env.FILESIR_API_BASE||"https://my.files.ir/api/v1",e=process.env.FILESIR_PUBLIC_BASE||"https://my.files.ir";function f(){return!!(process.env.FILESIR_ACCESS_TOKEN?.trim()||process.env.FILESIR_EMAIL?.trim()&&process.env.FILESIR_PASSWORD)}function g(a){return`${e}/drive/s/${a}`}},82082:(a,b,c)=>{"use strict";c.d(b,{Ak:()=>i,M5:()=>j,Yu:()=>k,ns:()=>g});var d=c(79418);let e=null,f=0;class g extends Error{constructor(a,b,c){super(a),this.name="FilesIrError",this.status=b,this.body=c}}async function h(){let a=process.env.FILESIR_EMAIL?.trim(),b=process.env.FILESIR_PASSWORD;if(!a||!b)throw new g("FILESIR_ACCESS_TOKEN یا FILESIR_EMAIL/PASSWORD تنظیم نشده.",503);let c=await fetch(`${d.eW}/auth/login`,{method:"POST",headers:{"Content-Type":"application/json",Accept:"application/json"},body:JSON.stringify({email:a,password:b,token_name:process.env.FILESIR_TOKEN_NAME||"liobiz-server"})}),h=await c.json().catch(()=>({}));if(!c.ok||!h.user?.access_token)throw new g(h.message||"ورود Files.ir ناموفق بود.",c.status||401,h);return e=h.user.access_token,f=Date.now()+33e5,e}async function i(){let a=process.env.FILESIR_ACCESS_TOKEN?.trim();return a||(e&&Date.now()<f?e:h())}async function j(a,b={}){let c=await i(),e=new Headers(b.headers);e.set("Authorization",`Bearer ${c}`),e.set("Accept","application/json");let f=await fetch(`${d.eW}${a}`,{...b,headers:e});if(b.rawBody&&f.ok)return f;let h=(f.headers.get("content-type")||"").includes("application/json")?await f.json().catch(()=>({})):await f.text().catch(()=>"");if(!f.ok)throw new g("object"==typeof h&&h&&"message"in h?String(h.message):`Files.ir error ${f.status}`,f.status,h);return h}async function k(a,b){let c=await i(),e=await fetch(`${d.eW}${a}`,{method:"POST",headers:{Authorization:`Bearer ${c}`,Accept:"application/json"},body:b}),f=await e.json().catch(()=>({}));if(!e.ok)throw new g("object"==typeof f&&f&&"message"in f?String(f.message):`Files.ir error ${e.status}`,e.status,f);return f}},84862:(a,b,c)=>{"use strict";c.d(b,{jd:()=>E,dI:()=>C,X:()=>s,Lf:()=>D,$e:()=>x,uP:()=>u,Ww:()=>t,xS:()=>w,QI:()=>v,VV:()=>r});var d={};c.r(d),c.d(d,{contactMessages:()=>s,notifications:()=>x,orderFiles:()=>u,orders:()=>t,ticketMessages:()=>w,tickets:()=>v,users:()=>r});var e=c(87550),f=c.n(e),g=c(67329),h=c(48689),i=c(7028),j=c(29021),k=c.n(j),l=c(33873),m=c.n(l),n=c(22709),o=c(12873),p=c(20377),q=c(58040);let r=(0,o.D)("users",{id:(0,p.nd)("id").primaryKey({autoIncrement:!0}),name:(0,q.Qq)("name").notNull(),email:(0,q.Qq)("email").notNull().unique(),passwordHash:(0,q.Qq)("password_hash").notNull(),role:(0,q.Qq)("role",{enum:["admin","client"]}).notNull().default("client"),phone:(0,q.Qq)("phone"),company:(0,q.Qq)("company"),blocked:(0,p.nd)("blocked",{mode:"boolean"}).notNull().default(!1),blockReason:(0,q.Qq)("block_reason"),createdAt:(0,q.Qq)("created_at").notNull(),updatedAt:(0,q.Qq)("updated_at")}),s=(0,o.D)("contact_messages",{id:(0,p.nd)("id").primaryKey({autoIncrement:!0}),name:(0,q.Qq)("name").notNull(),email:(0,q.Qq)("email").notNull(),phone:(0,q.Qq)("phone").notNull(),message:(0,q.Qq)("message").notNull(),status:(0,q.Qq)("status",{enum:["new","read","closed"]}).notNull().default("new"),createdAt:(0,q.Qq)("created_at").notNull()}),t=(0,o.D)("orders",{id:(0,p.nd)("id").primaryKey({autoIncrement:!0}),userId:(0,p.nd)("user_id").notNull(),title:(0,q.Qq)("title").notNull(),service:(0,q.Qq)("service").notNull(),description:(0,q.Qq)("description").notNull(),budget:(0,q.Qq)("budget"),status:(0,q.Qq)("status",{enum:["new","review","in_progress","completed","cancelled"]}).notNull().default("new"),adminNote:(0,q.Qq)("admin_note"),createdAt:(0,q.Qq)("created_at").notNull(),updatedAt:(0,q.Qq)("updated_at").notNull()}),u=(0,o.D)("order_files",{id:(0,p.nd)("id").primaryKey({autoIncrement:!0}),orderId:(0,p.nd)("order_id").notNull(),uploadedBy:(0,p.nd)("uploaded_by").notNull(),fileName:(0,q.Qq)("file_name").notNull(),fileUrl:(0,q.Qq)("file_url").notNull(),kind:(0,q.Qq)("kind",{enum:["request","delivery"]}).notNull().default("delivery"),createdAt:(0,q.Qq)("created_at").notNull()}),v=(0,o.D)("tickets",{id:(0,p.nd)("id").primaryKey({autoIncrement:!0}),userId:(0,p.nd)("user_id").notNull(),orderId:(0,p.nd)("order_id"),subject:(0,q.Qq)("subject").notNull(),status:(0,q.Qq)("status",{enum:["open","answered","closed"]}).notNull().default("open"),createdAt:(0,q.Qq)("created_at").notNull(),updatedAt:(0,q.Qq)("updated_at").notNull()}),w=(0,o.D)("ticket_messages",{id:(0,p.nd)("id").primaryKey({autoIncrement:!0}),ticketId:(0,p.nd)("ticket_id").notNull(),senderId:(0,p.nd)("sender_id").notNull(),senderRole:(0,q.Qq)("sender_role",{enum:["admin","client"]}).notNull(),body:(0,q.Qq)("body").notNull(),createdAt:(0,q.Qq)("created_at").notNull()}),x=(0,o.D)("notifications",{id:(0,p.nd)("id").primaryKey({autoIncrement:!0}),userId:(0,p.nd)("user_id").notNull(),title:(0,q.Qq)("title").notNull(),body:(0,q.Qq)("body").notNull(),href:(0,q.Qq)("href"),read:(0,p.nd)("read",{mode:"boolean"}).notNull().default(!1),createdAt:(0,q.Qq)("created_at").notNull()}),y=(0,n.ok)(),z=m().join(y,"liobiz.db"),A=null,B=null;function C(){if(B)try{B.close()}catch{}B=null,A=null}function D(){if(A)return A;k().mkdirSync(y,{recursive:!0});let a=new(f())(z);B=a,a.pragma("journal_mode = WAL");a.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'client',
      phone TEXT,
      company TEXT,
      blocked INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT
    );

    CREATE TABLE IF NOT EXISTS contact_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL,
      message TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'new',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      service TEXT NOT NULL,
      description TEXT NOT NULL,
      budget TEXT,
      status TEXT NOT NULL DEFAULT 'new',
      admin_note TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS order_files (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL,
      uploaded_by INTEGER NOT NULL,
      file_name TEXT NOT NULL,
      file_url TEXT NOT NULL,
      kind TEXT NOT NULL DEFAULT 'delivery',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS tickets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      order_id INTEGER,
      subject TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'open',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS ticket_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ticket_id INTEGER NOT NULL,
      sender_id INTEGER NOT NULL,
      sender_role TEXT NOT NULL,
      body TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      body TEXT NOT NULL,
      href TEXT,
      read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );
  `);let b=new Set(a.prepare("PRAGMA table_info(users)").all().map(a=>a.name));b.has("blocked")||a.exec("ALTER TABLE users ADD COLUMN blocked INTEGER NOT NULL DEFAULT 0"),b.has("block_reason")||a.exec("ALTER TABLE users ADD COLUMN block_reason TEXT"),b.has("updated_at")||a.exec("ALTER TABLE users ADD COLUMN updated_at TEXT");var c=A=(0,g.f)(a,{schema:d});let e=(process.env.ADMIN_EMAIL||"admin@liobiz.com").toLowerCase().trim(),j=process.env.ADMIN_PASSWORD||"Admin@12345",l=process.env.ADMIN_NAME||"مدیر لیوبیز";return c.select().from(r).where((0,h.eq)(r.email,e)).get()||(process.env.ADMIN_PASSWORD||console.warn("[liobiz] ADMIN_PASSWORD is not set. Seeding default admin — change it immediately after first login."),c.insert(r).values({name:l,email:e,passwordHash:i.Ay.hashSync(j,10),role:"admin",phone:null,company:"لیوبیز",blocked:!1,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()}).run()),!function(a){let b=m().join(y,"contact-messages.json");if(k().existsSync(b))try{let c=k().readFileSync(b,"utf8"),d=JSON.parse(c);if(!Array.isArray(d)||0===d.length||a.select().from(s).all().length>0)return;for(let b of d)b.name&&b.email&&b.phone&&b.message&&a.insert(s).values({name:b.name,email:b.email,phone:b.phone,message:b.message,status:"new",createdAt:b.createdAt||new Date().toISOString()}).run()}catch{}}(A),A}function E(){B||D(),B?.pragma("wal_checkpoint(TRUNCATE)")}},96487:()=>{}};